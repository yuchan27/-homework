import 'package:flutter/material.dart';

void main() {
  runApp(const MyResumeApp());
}

class MyResumeApp extends StatelessWidget {
  const MyResumeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '我的自傳',
      debugShowCheckedModeBanner: false, // 隱藏右上角的 Debug 標籤
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
        scaffoldBackgroundColor: Colors.grey[100],
        useMaterial3: true,
      ),
      home: const ResumeScreen(),
    );
  }
}

class ResumeScreen extends StatelessWidget {
  const ResumeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // ▼▼▼ 這裡填寫 App 頂部的標題 ▼▼▼
        title: const Text("我的自傳"),
        centerTitle: true,
        backgroundColor: Theme.of(context).primaryColor,
        foregroundColor: Colors.white,
      ),
      // 使用 SingleChildScrollView 讓內容超過螢幕時可以捲動
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              // --- 1. 個人頭像與基本資料區 ---
              const SizedBox(height: 20),
              Center(
                child: CircleAvatar(
                  radius: 60, // 頭像大小
                  backgroundColor: Colors.grey[300],
                  backgroundImage: NetworkImage('https://img.freepik.com/free-photo/close-up-portrait-beautiful-cat_23-2149214384.jpg?semt=ais_hybrid&w=740&q=80'),
                ),
              ),
              const SizedBox(height: 15),

              const Text(
                "簡佑丞(YU CHENG, CHIEN)",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),

              const SizedBox(height: 5),

              Text(
                "高科大 | 法式滾球 | 寫程式",
                style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey[700],
                    fontWeight: FontWeight.w500
                ),
              ),

              const SizedBox(height: 30),

              // --- 2. 聯絡方式區塊 ---
              _buildInfoCard(Icons.email, "電子郵件", "wuwu6249@gmail.com"),
              _buildInfoCard(Icons.phone, "聯絡電話", "0908-235-260"),
              _buildInfoCard(Icons.location_on, "居住地點", "台灣, 台北市(目前暫居高雄)"),

              const SizedBox(height: 25),
              const Divider(thickness: 1.5),
              const SizedBox(height: 25),

              // --- 3. 關於我 (About Me) ---
              _buildSectionTitle("關於我 (About Me)"),
              const Card(
                elevation: 5,
                color: Colors.white,
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text(
                    "您好！我目前就讀於高科大，是資工系大三的學生，我的名字是簡佑丞，我平常喜歡打程式、遊戲、聽音樂等等...目前主要研究方向在AI的部分",
                    style: TextStyle(fontSize: 18, height: 1.5), // height 設定行距
                  ),
                ),
              ),

              const SizedBox(height: 25),

              // --- 4. 學歷 / 經歷 ---
              _buildSectionTitle("經歷與學歷"),

              //我的經歷，可以直接複製貼上下面的
              _buildExperienceRow(
                year: "2023/7-至今\n(就讀中)",
                title: "國立高雄科技大學",
                subtitle: "資訊工程學系 大三學生",
              ),
              _buildExperienceRow(
                year: "2022/11",
                title: "數位電子乙級執照",
                subtitle: "",
              ),
              _buildExperienceRow(
                year: "2022/8",
                title: "智慧鐵人創意競賽",
                subtitle: "隊名:勞贖\n成績: 技職組全國第二名",
              ),
              _buildExperienceRow(
                year: "2020/9 - 2023/6",
                title: "臺北市立木柵高級工業職業學校",
                subtitle: "電子科",
              ),
              _buildExperienceRow(
                year: "2017/9 - 2020/6",
                title: "臺北市立大安國民中學",
                subtitle: "普通班",
              ),

              const SizedBox(height: 25),

              _buildSectionTitle("專業技能"),
              Wrap(
                spacing: 10, // 標籤水平間距
                runSpacing: 5, // 標籤垂直間距
                children: [
                  //下方可以增加技能標籤
                  _buildSkillChip("法式滾球"),
                  _buildSkillChip("java"),
                  _buildSkillChip("python"),
                  _buildSkillChip("AI(略懂)"),
                  _buildSkillChip("Git(略懂)"),
                  _buildSkillChip("焊接"),
                  _buildSkillChip("中文"),
                ],
              ),

              const SizedBox(height: 50), // 底部留白
            ],
          ),
        ),
      ),
    );
  }
  //下列皆為函式
  // 建立標題文字的樣式
  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          title,
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.blueGrey, // 標題顏色
          ),
        ),
      ),
    );
  }

  // 建立聯絡資訊卡片的樣式
  Widget _buildInfoCard(IconData icon, String title, String content) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5),
      color: Colors.white,
      child: ListTile(
        leading: Icon(icon, color: Colors.blueGrey),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        subtitle: Text(content, style: const TextStyle(fontSize: 16, color: Colors.black87)),
      ),
    );
  }

  // 建立經歷/學歷列的樣式
  Widget _buildExperienceRow({required String year, required String title, required String subtitle}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 年份區塊
            Container(
              width: 100,
              padding: const EdgeInsets.only(right: 10),
              child: Text(
                year,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.blueGrey,
                ),
              ),
            ),
            // 內容區塊
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    subtitle,
                    style: const TextStyle(fontSize: 15, height: 1.4),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 建立技能標籤的樣式
  Widget _buildSkillChip(String label) {
    return Chip(
      label: Text(label),
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(color: Colors.blueGrey.shade100),
      ),
      elevation: 1,
    );
  }
}